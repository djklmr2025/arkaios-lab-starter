// ai-chat content placeholder
